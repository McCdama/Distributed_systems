package io.dis.myaktion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyaktionBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
