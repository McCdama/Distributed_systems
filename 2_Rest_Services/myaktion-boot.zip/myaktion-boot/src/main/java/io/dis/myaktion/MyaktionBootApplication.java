package io.dis.myaktion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyaktionBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyaktionBootApplication.class, args);
	}

}
